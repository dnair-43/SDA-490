# =============================================================================
# prepare_data.R
# Run this ONCE on your local machine before deploying to shinyapps.io.
# It trims each large data file down to only the rows and columns the app
# actually uses, then saves as compressed .rds files.
#
# After running this script, deploy ONLY the .rds files (not the raw CSVs).
# Typical size reduction: V-Dem 500MB -> ~2MB, WVS 200MB -> ~1MB
#
# Usage: open this file in RStudio and click Source, or run:
#   source("prepare_data.R")
# =============================================================================

library(readr)
library(dplyr)
library(tidyr)
library(haven)

# Set this to the folder containing your raw data files
data_dir <- "."   # change if your data files are in a different folder
out_dir  <- "."   # where to write the .rds files (same folder as app.R)

cat("Starting data preparation...\n\n")

# Helper: find a file trying several candidate names across dirs
find_file <- function(..., dirs = unique(c(data_dir, ".", getwd()))) {
  candidates <- c(...)
  for (d in dirs) {
    for (f in candidates) {
      p <- file.path(d, f)
      if (file.exists(p)) return(p)
    }
  }
  return(NULL)
}

# =============================================================================
# 1. V-DEM  ->  vdem_slim.rds
# =============================================================================
vdem_path <- find_file(
  "V-Dem-CD-v16.csv", "V-Dem-CD-v16.csv.gz",
  "V-Dem-CY-Full+Others-v16.csv", "V-Dem-CY-Full+Others-v16.csv.gz"
)

if (!is.null(vdem_path)) {
  cat("Reading V-Dem:", basename(vdem_path), "(may take a minute)...\n")
  vdem_full <- read_csv(vdem_path, show_col_types = FALSE)
  vdem_slim <- vdem_full %>%
    filter(year >= 1980, year <= 2025) %>%
    select(any_of(c("country_name","country_text_id","year",
                    "v2x_polyarchy","v2cacamps","v2xps_party",
                    "v2mecenefm","v2lgfunds")))
  saveRDS(vdem_slim, file.path(out_dir, "vdem_slim.rds"), compress = "xz")
  cat(sprintf("  OK vdem_slim.rds: %d rows x %d cols  (%.1f MB)\n",
              nrow(vdem_slim), ncol(vdem_slim),
              file.size(file.path(out_dir, "vdem_slim.rds")) / 1e6))
  rm(vdem_full); gc()
} else {
  cat("  SKIP: No V-Dem CSV found in", data_dir, "\n")
}

# =============================================================================
# 2. WVS  ->  wvs_slim.rds
#    Handles ALL common WVS distribution formats automatically:
#      .rds   WVS_Time_Series_1981-2022_rds_v5_0.rds   (most common download)
#      .rdata WVS_Time_Series_1981-2022_rdata_v5_0.rdata
#      .csv   WVS_Time_Series_1981-2022_csv_v2_0.csv
#      .sav   WVS SPSS file
#      WVS.csv / WVS.rds  (renamed files)
# =============================================================================
wvs_countries_list <- c(
  "Belarus","India","Hungary","United States","Russia",
  "Venezuela","Burkina Faso","Nicaragua","Mali","Niger",
  "Tunisia","Turkey","Canada"
)

wvs_iso_map <- c(
  "112"="Belarus","356"="India","348"="Hungary","840"="United States",
  "643"="Russia","862"="Venezuela","854"="Burkina Faso","558"="Nicaragua",
  "466"="Mali","562"="Niger","788"="Tunisia","792"="Turkey","124"="Canada"
)

auth_vars <- c("E114","E116","E115","E018","A042",
               "E225","E228","A124_06","A124_12","A124_43")

wvs_full <- NULL

# --- Try .rds ---
wvs_rds <- find_file(
  "WVS_Time_Series_1981-2022_rds_v5_0.rds",
  "WVS_TimeSeries_1981_2020_R_v2_0.rds",
  "WVS_Time_Series_1981-2022_v2_0.rds",
  "WVS.rds"
)
if (!is.null(wvs_rds)) {
  cat("Reading WVS RDS:", basename(wvs_rds), "...\n")
  wvs_full <- tryCatch({
    obj <- readRDS(wvs_rds)
    # readRDS sometimes returns the object directly, sometimes an env
    if (is.data.frame(obj)) obj
    else {
      e <- new.env(); load(wvs_rds, envir = e)
      get(ls(e)[1], envir = e)
    }
  }, error = function(e) {
    e2 <- new.env(); load(wvs_rds, envir = e2)
    get(ls(e2)[1], envir = e2)
  })
}

# --- Try .rdata / .RData ---
if (is.null(wvs_full) || !is.data.frame(wvs_full)) {
  wvs_rdata <- find_file(
    "WVS_Time_Series_1981-2022_rdata_v5_0.rdata",
    "WVS_Time_Series_1981-2022_R_v5_0.RData",
    "WVS.RData","WVS.rdata"
  )
  if (!is.null(wvs_rdata)) {
    cat("Reading WVS RData:", basename(wvs_rdata), "...\n")
    e <- new.env(); load(wvs_rdata, envir = e)
    wvs_full <- get(ls(e)[1], envir = e)
  }
}

# --- Try .csv ---
if (is.null(wvs_full) || !is.data.frame(wvs_full)) {
  wvs_csv <- find_file(
    "WVS_Time_Series_1981-2022_csv_v2_0.csv",
    "WVS_TimeSeries_1981_2020_csv_v2_0.csv",
    "WVS.csv"
  )
  if (!is.null(wvs_csv)) {
    cat("Reading WVS CSV:", basename(wvs_csv), "...\n")
    wvs_full <- read_csv(wvs_csv, show_col_types = FALSE)
  }
}

# --- Try .sav ---
if (is.null(wvs_full) || !is.data.frame(wvs_full)) {
  wvs_sav <- find_file("WVS_Time_Series_1981-2022_spss_v2_0.sav","WVS.sav")
  if (!is.null(wvs_sav)) {
    cat("Reading WVS SAV:", basename(wvs_sav), "...\n")
    wvs_full <- haven::read_sav(wvs_sav)
  }
}

if (!is.null(wvs_full) && is.data.frame(wvs_full)) {
  cat("  WVS loaded:", nrow(wvs_full), "rows x", ncol(wvs_full), "cols\n")
  
  # Strip haven labels if present
  if (any(sapply(wvs_full, haven::is.labelled))) {
    wvs_full <- wvs_full %>%
      mutate(across(everything(), ~ suppressWarnings(haven::zap_labels(.))))
  }
  
  # ── Normalise to country + year columns ─────────────────────────────────────
  # Case 1: numeric S003 country code (most common in official WVS downloads)
  if ("S003" %in% names(wvs_full) && !"country" %in% names(wvs_full)) {
    cat("  Detected S003 numeric country codes\n")
    wvs_full <- wvs_full %>%
      mutate(country = wvs_iso_map[as.character(as.integer(S003))],
             year    = as.integer(S020)) %>%
      filter(!is.na(country))
    
    # Case 2: alpha-3 COW country codes (B_COUNTRY_ALPHA)
  } else if ("B_COUNTRY_ALPHA" %in% names(wvs_full) && !"country" %in% names(wvs_full)) {
    cat("  Detected B_COUNTRY_ALPHA codes\n")
    cow_map <- c(IND="India",BLR="Belarus",HUN="Hungary",USA="United States",
                 RUS="Russia",VEN="Venezuela",BFA="Burkina Faso",NIC="Nicaragua",
                 MLI="Mali",NER="Niger",TUN="Tunisia",TUR="Turkey",CAN="Canada")
    yr_col <- intersect(c("S020","YEAR","year"), names(wvs_full))[1]
    wvs_full <- wvs_full %>%
      mutate(country = cow_map[as.character(B_COUNTRY_ALPHA)],
             year    = as.integer(.data[[yr_col]])) %>%
      filter(!is.na(country))
    
    # Case 3: country_name column
  } else if ("country_name" %in% names(wvs_full) && !"country" %in% names(wvs_full)) {
    cat("  Detected country_name column\n")
    wvs_full <- wvs_full %>% rename(country = country_name)
    
    # Case 4: country column already exists — check if values match
  } else if ("country" %in% names(wvs_full)) {
    cat("  Found existing 'country' column\n")
    cat("  Sample values:", paste(head(unique(wvs_full$country), 6), collapse=", "), "\n")
    # If country column contains numeric codes, convert
    if (is.numeric(wvs_full$country) || all(grepl("^\\d+$", na.omit(head(wvs_full$country, 20))))) {
      cat("  Converting numeric country codes...\n")
      wvs_full <- wvs_full %>%
        mutate(country = wvs_iso_map[as.character(as.integer(country))]) %>%
        filter(!is.na(country))
    }
  }
  
  # Ensure year is integer
  yr_col2 <- intersect(c("year","S020","YEAR"), names(wvs_full))[1]
  if (!is.na(yr_col2) && yr_col2 != "year") {
    wvs_full <- wvs_full %>% mutate(year = as.integer(.data[[yr_col2]]))
  } else if ("year" %in% names(wvs_full)) {
    wvs_full <- wvs_full %>% mutate(year = as.integer(year))
  }
  
  cat("  After normalisation:", nrow(wvs_full), "rows,",
      length(unique(wvs_full$country)), "countries\n")
  
  # Keep only the columns the app needs (take what exists)
  wvs_slim <- wvs_full %>%
    filter(country %in% wvs_countries_list) %>%
    select(any_of(c("country", "year", auth_vars)))
  
  cat("  After country filter:", nrow(wvs_slim), "rows\n")
  cat("  Auth vars kept:", paste(intersect(auth_vars, names(wvs_slim)), collapse=", "), "\n")
  
  if (nrow(wvs_slim) == 0) {
    cat("  WARNING: 0 rows — country names may not match. Trying S003 fallback...\n")
    # Last-resort: try matching via S003 if column exists
    if ("S003" %in% names(wvs_full)) {
      wvs_slim <- wvs_full %>%
        mutate(country2 = wvs_iso_map[as.character(as.integer(S003))]) %>%
        filter(!is.na(country2)) %>%
        rename(country = country2) %>%
        select(any_of(c("country", "year", auth_vars)))
      cat("  After S003 fallback:", nrow(wvs_slim), "rows\n")
    }
  }
  
  if (nrow(wvs_slim) > 0) {
    saveRDS(wvs_slim, file.path(out_dir, "wvs_slim.rds"), compress = "xz")
    cat(sprintf("  OK wvs_slim.rds: %d rows x %d cols  (%.1f KB)\n",
                nrow(wvs_slim), ncol(wvs_slim),
                file.size(file.path(out_dir, "wvs_slim.rds")) / 1e3))
  } else {
    cat("  FAILED to create wvs_slim.rds — no matching rows found.\n")
    cat("  The app will fall back to synthetic WVS data.\n")
  }
  rm(wvs_full); gc()
} else {
  cat("  SKIP: No WVS file found. Searched for:\n")
  cat("    WVS_Time_Series_1981-2022_rds_v5_0.rds  (most common)\n")
  cat("    WVS_Time_Series_1981-2022_rdata_v5_0.rdata\n")
  cat("    WVS_Time_Series_1981-2022_csv_v2_0.csv\n")
  cat("    WVS.csv / WVS.rds / WVS.sav\n")
  cat("  -> Rename your WVS file to WVS.rds (or WVS.csv) and re-run.\n")
}

# =============================================================================
# 3. GINI  ->  gini_slim.rds
# =============================================================================
wb_to_wvs <- c(
  "United States"="United States","United Kingdom"="United Kingdom",
  "Russian Federation"="Russia","Venezuela, RB"="Venezuela",
  "Burkina Faso"="Burkina Faso","Nicaragua"="Nicaragua",
  "Mali"="Mali","Niger"="Niger","Tunisia"="Tunisia",
  "Turkiye"="Turkey","Turkey"="Turkey","Canada"="Canada",
  "India"="India","Hungary"="Hungary","Belarus"="Belarus"
)

gini_path <- find_file("GINI_DATA.csv","GINI_DATA.csv.gz")
if (!is.null(gini_path)) {
  cat("Reading GINI:", basename(gini_path), "...\n")
  gini_raw  <- read_csv(gini_path, show_col_types = FALSE, skip_empty_rows = TRUE)
  year_cols <- names(gini_raw)[grepl("^\\d{4}$", names(gini_raw))]
  if (length(year_cols) > 0) {
    gini_slim <- gini_raw %>%
      select(country = 1, all_of(year_cols)) %>%
      filter(country %in% names(wb_to_wvs)) %>%
      mutate(country = wb_to_wvs[country]) %>%
      pivot_longer(all_of(year_cols), names_to = "year", values_to = "gini") %>%
      mutate(year = as.integer(year), gini = suppressWarnings(as.numeric(gini))) %>%
      filter(!is.na(gini), year >= 1980, year <= 2025)
  } else {
    names(gini_raw) <- tolower(names(gini_raw))
    gc <- intersect(c("gini","gini_index","gini_coefficient"), names(gini_raw))[1]
    gini_slim <- gini_raw %>%
      rename(gini = all_of(gc)) %>%
      select(country, year, gini) %>%
      mutate(year = as.integer(year), gini = as.numeric(gini),
             country = dplyr::recode(country, !!!wb_to_wvs)) %>%
      filter(!is.na(gini), year >= 1980, year <= 2025,
             country %in% wvs_countries_list)
  }
  saveRDS(gini_slim, file.path(out_dir, "gini_slim.rds"), compress = "xz")
  cat(sprintf("  OK gini_slim.rds: %d rows x %d cols  (%.1f KB)\n",
              nrow(gini_slim), ncol(gini_slim),
              file.size(file.path(out_dir, "gini_slim.rds")) / 1e3))
} else {
  cat("  SKIP: GINI_DATA.csv not found in", data_dir, "\n")
}

# =============================================================================
# 4. ELECTION  ->  election_slim.rds
# =============================================================================
election_path <- find_file("table_tableau08.csv")
if (!is.null(election_path)) {
  cat("Reading election data...\n")
  election_slim <- read_csv(election_path,
                            locale = locale(encoding = "UTF-8"),
                            show_col_types = FALSE)
  saveRDS(election_slim, file.path(out_dir, "election_slim.rds"), compress = "xz")
  cat(sprintf("  OK election_slim.rds: %d rows  (%.1f KB)\n",
              nrow(election_slim),
              file.size(file.path(out_dir, "election_slim.rds")) / 1e3))
} else {
  cat("  SKIP: table_tableau08.csv not found in", data_dir, "\n")
}

# =============================================================================
# 5. CTM  ->  ctm_slim.rds
# =============================================================================
ctm_path <- find_file("CTM_DATA.sav","CTM_DATA.SAV")
if (!is.null(ctm_path)) {
  cat("Reading CTM SAV...\n")
  ctm_auth_vars <- c("HD3","V3","ATT10","HD4","V2")
  region_keys   <- c("BC_REG","NS_REG","NL_REG","MB_REG","AB_REG5","AB_REG4",
                     "AB_REG3","ON_REG","ON_REG4","ON_REG2","QC_REG2","QC_REG4",
                     "SK_REG","SK_REG3","NB_REG4","NB_REG")
  ctm_full  <- read_sav(ctm_path)
  keep_cols <- intersect(c(ctm_auth_vars, region_keys), names(ctm_full))
  ctm_slim  <- ctm_full %>% select(all_of(keep_cols))
  saveRDS(ctm_slim, file.path(out_dir, "ctm_slim.rds"), compress = "xz")
  cat(sprintf("  OK ctm_slim.rds: %d rows x %d cols  (%.1f KB)\n",
              nrow(ctm_slim), ncol(ctm_slim),
              file.size(file.path(out_dir, "ctm_slim.rds")) / 1e3))
  rm(ctm_full); gc()
} else {
  cat("  SKIP: CTM_DATA.sav not found in", data_dir, "\n")
}

# =============================================================================
cat("\nDone!\n\n")
cat("Deploy your app with ONLY the .rds files — no raw CSVs needed.\n")
cat("Files to deploy alongside app.R:\n")
rds_files <- list.files(out_dir, pattern = "_slim\\.rds$", full.names = TRUE)
for (f in rds_files) cat(sprintf("  %-30s  %.2f MB\n", basename(f), file.size(f)/1e6))
total_mb <- sum(file.size(rds_files)) / 1e6
cat(sprintf("\nTotal .rds size: %.2f MB\n", total_mb))

# =============================================================================
# 6. WDI GNI  ->  wdi_slim.rds
#    Fetches logged GNI per capita for the 13 countries from World Bank API.
#    Saves result so the app never needs internet access after this.
# =============================================================================
cat("Fetching WDI GNI data from World Bank API...\n")
wdi_iso2_map <- c(
  "Belarus"="BY","India"="IN","Hungary"="HU","United States"="US",
  "Russia"="RU","Venezuela"="VE","Burkina Faso"="BF","Nicaragua"="NI",
  "Mali"="ML","Niger"="NE","Tunisia"="TN","Turkey"="TR","Canada"="CA"
)

wdi_slim <- tryCatch({
  library(WDI)
  raw <- WDI(indicator="NY.GNP.PCAP.PP.CD",
             country=unname(wdi_iso2_map),
             start=1980, end=2025)
  iso2_to_name <- setNames(names(wdi_iso2_map), wdi_iso2_map)
  raw %>%
    filter(!is.na(NY.GNP.PCAP.PP.CD)) %>%
    transmute(country=iso2_to_name[iso2c],
              year=as.integer(year),
              logged_wealth=log(NY.GNP.PCAP.PP.CD)) %>%
    filter(!is.na(country))
}, error = function(e) {
  cat("  WARNING: WDI fetch failed:", conditionMessage(e), "\n")
  cat("  -> wdi_slim.rds not created. App will try API at startup.\n")
  NULL
})

if (!is.null(wdi_slim) && nrow(wdi_slim) > 0) {
  saveRDS(wdi_slim, file.path(out_dir, "wdi_slim.rds"), compress="xz")
  cat(sprintf("  OK wdi_slim.rds: %d rows  (%.1f KB)\n",
              nrow(wdi_slim),
              file.size(file.path(out_dir,"wdi_slim.rds"))/1e3))
}
