library(rsconnect)

# Change this to the actual path of your app folder
app_folder <- "~/Desktop/SDA 490/Shiny App/Authoritarianism"

deployApp(
  appDir   = app_folder,
  appFiles = c(
    "app.R",
    "vdem_slim.rds",
    "wvs_slim.rds",
    "gini_slim.rds",
    "election_slim.rds",
    "ctm_slim.rds",
    "wdi_slim.rds",
    "Timeline_picture.png",
    "Top_10_countries.png"
  ),
  appName  = "democracy-index-map"   # whatever name you want on shinyapps.io
)
